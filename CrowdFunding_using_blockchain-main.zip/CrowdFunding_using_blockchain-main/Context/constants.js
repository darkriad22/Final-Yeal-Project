// Context/constants.js
import CrowdFundingArtifact from "../artifacts/contracts/CrowdFunding.sol/CrowdFunding.json";

// ✅ NOTE:
// - CrowFunding.sol compile করলে ABI auto-update হবে (artifacts থেকে আসে)
// - Deploy করলে address change হতে পারে, deploy.js এ যেটা print হবে সেটাই বসাবে
export const CrowdFundingAddress = "0x5FbDB2315678afecb367f032d93F642f64180aa3";
export const CrowdFundingABI = CrowdFundingArtifact.abi;
