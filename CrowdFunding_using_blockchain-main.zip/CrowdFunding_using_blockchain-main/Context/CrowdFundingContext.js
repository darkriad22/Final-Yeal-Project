// Context/CrowdFundingContext.js
import React, { createContext, useState, useEffect } from "react";
import Web3Modal from "web3modal";
import { ethers } from "ethers";
import { CrowdFundingABI, CrowdFundingAddress } from "./constants";

const fetchContract = (signerOrProvider) =>
  new ethers.Contract(CrowdFundingAddress, CrowdFundingABI, signerOrProvider);

const RPC_HTTP = process.env.NEXT_PUBLIC_RPC_HTTP || "http://127.0.0.1:8545";
const roProvider = () => new ethers.providers.JsonRpcProvider(RPC_HTTP);

export const CrowdFundingContext = createContext();

export const CrowdFundingProvider = ({ children }) => {
  const titleData = "Crowd Funding Contract";

  const [currentAccount, setCurrentAccount] = useState("");
  const [campaigns, setCampaigns] = useState([]);
  const [searchResults, setSearchResults] = useState([]);

  /* ---------------- Wallet / Provider ---------------- */

  const getProvider = async () => {
    const web3Modal = new Web3Modal();
    const connection = await web3Modal.connect();
    const provider = new ethers.providers.Web3Provider(connection);
    return { provider, signer: provider.getSigner() };
  };

  const connectWallet = async () => {
    if (!window.ethereum) return;
    const accounts = await window.ethereum.request({
      method: "eth_requestAccounts",
    });
    setCurrentAccount(accounts[0]);
  };

  const checkIfWalletConnected = async () => {
    if (!window.ethereum) return;
    const accounts = await window.ethereum.request({ method: "eth_accounts" });
    if (accounts.length) setCurrentAccount(accounts[0]);
  };

  /* ---------------- Member ---------------- */

  const registerMember = async (name) => {
    if (!name) throw new Error("Name required");

    const providerRO = roProvider();
    const contractRO = fetchContract(providerRO);

    const accounts = await window.ethereum.request({ method: "eth_accounts" });
    const who = accounts?.[0];
    if (!who) throw new Error("Connect wallet");

    const already = await contractRO.isMember(who);
    if (already) throw new Error("Already registered");

    const { signer } = await getProvider();
    const contract = fetchContract(signer);

    const tx = await contract.register(name);
    await tx.wait();
    return true;
  };

  const checkIsMember = async (addr) => {
    try {
      const provider = roProvider();
      const contract = fetchContract(provider);

      let who = addr;
      if (!who && window?.ethereum) {
        const accounts = await window.ethereum.request({ method: "eth_accounts" });
        who = accounts?.[0];
      }
      if (!who) return false;

      return await contract.isMember(who);
    } catch (e) {
      console.log("checkIsMember error", e);
      return false;
    }
  };

  /* ---------------- Campaigns (Gas-optimized contract compatible) ---------------- */

  // ✅ IMPORTANT:
  // Optimized contract: createCampaign(owner, title, metadataURI, target, deadline, image_unused)
  // We will pack (description + image) into one metadataURI string so UI still works.
  // Example metadataURI: "DESC::<desc>||IMG::<imgURL>"
  const buildMetadataURI = (description, image) => {
    const desc = description || "";
    const img = image || "";
    return `DESC::${desc}||IMG::${img}`;
  };

  const parseMetadataURI = (metadataURI) => {
    try {
      const s = metadataURI || "";
      const parts = s.split("||");
      const descPart = parts.find((p) => p.startsWith("DESC::")) || "DESC::";
      const imgPart = parts.find((p) => p.startsWith("IMG::")) || "IMG::";
      const description = descPart.replace("DESC::", "");
      const image = imgPart.replace("IMG::", "");
      return { description, image, metadataURI: s };
    } catch (e) {
      return { description: "", image: "", metadataURI: metadataURI || "" };
    }
  };

  const createCampaign = async ({ title, description, amount, deadline, image }) => {
    const { signer } = await getProvider();
    const contract = fetchContract(signer);

    const deadlineSeconds = Math.floor(new Date(deadline).getTime() / 1000);
    const targetWei = ethers.utils.parseEther(amount);

    // ✅ metadataURI pack
    const metadataURI = buildMetadataURI(description, image);

    // NOTE: last param is unused string in optimized contract signature
    const tx = await contract.createCampaign(
      currentAccount,
      title,
      metadataURI,
      targetWei,
      deadlineSeconds,
      "" // unused in contract, keep signature stable
    );

    await tx.wait();
    await getCampaigns();
  };

  const getCampaigns = async () => {
    const provider = roProvider();
    const contract = fetchContract(provider);

    try {
      const list = await contract.getCampaigns();

      const parsed = list.map((c, i) => {
        const meta = parseMetadataURI(c.metadataURI);

        return {
          pId: i,
          owner: c.owner,
          title: c.title,

          // ✅ UI compatibility (we still provide description & image)
          description: meta.description,
          image: meta.image,
          metadataURI: meta.metadataURI,

          target: ethers.utils.formatEther(c.target),
          amountCollected: ethers.utils.formatEther(c.amountCollected),
          deadline: Number(c.deadline) * 1000,

          withdrawn: c.withdrawn,
          canceled: c.canceled,
          closed: c.closed,
          isDeleted: c.isDeleted,
        };
      });

      const visible = parsed.filter((c) => !c.isDeleted);
      setCampaigns(visible);
      return visible;
    } catch (e) {
      console.log("getCampaigns error", e);
      setCampaigns([]);
      return [];
    }
  };

  /* ---------------- Donation ---------------- */

  const donate = async (pId, amount) => {
    try {
      const isMem = await checkIsMember();
      if (!isMem) throw new Error("NOT_REGISTERED");

      // Read-only fetch latest campaign state directly from chain
      const providerRO = roProvider();
      const contractRO = fetchContract(providerRO);
      const c = (await contractRO.getCampaigns())[pId];

      if (c.isDeleted) throw new Error("CAMPAIGN_DELETED");
      if (c.canceled) throw new Error("CAMPAIGN_CANCELED");
      if (c.withdrawn) throw new Error("ALREADY_WITHDRAWN");
      if (c.closed) throw new Error("CAMPAIGN_CLOSED");
      if (Date.now() > Number(c.deadline) * 1000) throw new Error("CAMPAIGN_ENDED");

      const raised = parseFloat(ethers.utils.formatEther(c.amountCollected));
      const target = parseFloat(ethers.utils.formatEther(c.target));
      const amt = parseFloat(amount);

      if (raised >= target) throw new Error("TARGET_REACHED");
      if (raised + amt > target) throw new Error("EXCEEDS_TARGET");

      const { signer } = await getProvider();
      const contract = fetchContract(signer);

      const tx = await contract.donateToCampaign(pId, {
        value: ethers.utils.parseEther(amount),
      });
      const receipt = await tx.wait();

      await getCampaigns();

      const ev = receipt.events?.find((e) => e.event === "DonationMade");
      return { donationId: ev?.args?.donationId?.toString() };
    } catch (err) {
      console.log("donate error", err);
      throw err;
    }
  };

  // ✅ Gas optimized: donation history from EVENT logs (no getDonators)
  const getDonations = async (pId) => {
    try {
      const provider = roProvider();
      const iface = new ethers.utils.Interface(CrowdFundingABI);

      // event DonationMade(uint256 indexed campaignId, address indexed donator, uint256 amount, bytes32 donationId)
      const topic = iface.getEventTopic("DonationMade");

      // filter logs by contract address + event topic
      const logs = await provider.getLogs({
        address: CrowdFundingAddress,
        fromBlock: 0,
        toBlock: "latest",
        topics: [topic], // later we filter by campaignId
      });

      const parsed = logs
        .map((log) => {
          try {
            const decoded = iface.parseLog(log);
            return {
              campaignId: decoded.args.campaignId.toNumber(),
              donator: decoded.args.donator,
              amountWei: decoded.args.amount,
              donationId: decoded.args.donationId?.toString?.() || "",
              blockNumber: log.blockNumber,
              txHash: log.transactionHash,
            };
          } catch (e) {
            return null;
          }
        })
        .filter(Boolean)
        .filter((x) => Number(x.campaignId) === Number(pId))
        // newest first
        .sort((a, b) => Number(b.blockNumber) - Number(a.blockNumber));

      return parsed.map((x) => ({
        donator: x.donator,
        donation: ethers.utils.formatEther(x.amountWei.toString()),
        donationId: x.donationId,
        txHash: x.txHash,
      }));
    } catch (e) {
      console.log("getDonations(event logs) error", e);
      return [];
    }
  };

  /* ---------------- Escrow Actions ---------------- */

  const closeCampaign = async (pId) => {
    const { signer } = await getProvider();
    const contract = fetchContract(signer);
    const tx = await contract.closeCampaign(pId);
    await tx.wait();
    await getCampaigns();
  };

  // ✅ 1 TX cheaper path
  const closeAndWithdraw = async (pId) => {
    const { signer } = await getProvider();
    const contract = fetchContract(signer);
    const tx = await contract.closeAndWithdraw(pId);
    await tx.wait();
    await getCampaigns();
  };

  const withdraw = async (pId) => {
    const { signer } = await getProvider();
    const contract = fetchContract(signer);
    const tx = await contract.withdraw(pId);
    await tx.wait();
    await getCampaigns();
  };

  const refund = async (pId) => {
    const { signer } = await getProvider();
    const contract = fetchContract(signer);
    const tx = await contract.claimRefund(pId);
    await tx.wait();
    await getCampaigns();
  };

  const cancelCampaign = async (pId) => {
    const { signer } = await getProvider();
    const contract = fetchContract(signer);
    const tx = await contract.cancelCampaign(pId);
    await tx.wait();
    await getCampaigns();
  };

  const deleteCampaign = async (pId) => {
    const { signer } = await getProvider();
    const contract = fetchContract(signer);
    const tx = await contract.deleteCampaign(pId);
    await tx.wait();
    await getCampaigns();
  };

  const getMyContribution = async (pId, addr) => {
    try {
      const provider = roProvider();
      const contract = fetchContract(provider);

      let who = addr;
      if (!who && window?.ethereum) {
        const accounts = await window.ethereum.request({ method: "eth_accounts" });
        who = accounts?.[0];
      }
      if (!who) return "0";

      const amt = await contract.contributionOf(pId, who);
      return ethers.utils.formatEther(amt);
    } catch (e) {
      console.log("getMyContribution error", e);
      return "0";
    }
  };

  // ✅ Contract balance (all escrow in contract)
  const getContractBalance = async () => {
    try {
      const provider = roProvider();
      const bal = await provider.getBalance(CrowdFundingAddress);
      return ethers.utils.formatEther(bal);
    } catch (e) {
      console.log("getContractBalance error", e);
      return "0";
    }
  };

  /* ---------------- Search ---------------- */

  const searchCampaigns = (query) => {
    const filtered = campaigns.filter((c) =>
      c.title.toLowerCase().includes(query.toLowerCase())
    );
    setSearchResults(filtered);
  };

  useEffect(() => {
    checkIfWalletConnected();
    getCampaigns();

    if (window?.ethereum) {
      const handler = (accs) => setCurrentAccount(accs?.[0] || "");
      window.ethereum.on("accountsChanged", handler);
      return () => window.ethereum.removeListener("accountsChanged", handler);
    }
  }, []);

  return (
    <CrowdFundingContext.Provider
      value={{
        titleData,
        currentAccount,
        campaigns,
        searchResults,

        connectWallet,
        registerMember,
        checkIsMember,

        createCampaign,
        getCampaigns,
        donate,
        getDonations,

        closeCampaign,
        closeAndWithdraw, // ✅ NEW (1 tx)
        withdraw,
        refund,
        cancelCampaign,
        deleteCampaign,

        getMyContribution,
        getContractBalance,

        searchCampaigns,
      }}
    >
      {children}
    </CrowdFundingContext.Provider>
  );
};
