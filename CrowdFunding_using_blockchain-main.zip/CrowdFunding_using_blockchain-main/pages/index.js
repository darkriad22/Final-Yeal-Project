import React, { useEffect, useContext, useState } from "react";
import { useRouter } from "next/router";

// App components
import { Hero, Card, PopUp } from "../Components";
import { CrowdFundingContext } from "../Context/CrowdFundingContext";
import HomeButtons from "@/Components/HomeButtons";
import RegisterModal from "@/Components/RegisterModal";

const IndexPage = () => {
  const router = useRouter();
  const { titleData, getCampaigns, createCampaign, donate, searchResults, getDonations } =
    useContext(CrowdFundingContext);

  const showLayout = router.query.showLayout === "1";

  const [allcampaign, setAllcampaign] = useState();
  const [openModel, setOpenModel] = useState(false);
  const [donateCampaign, setDonateCampaign] = useState();
  const [openRegister, setOpenRegister] = useState(false);

  useEffect(() => {
    const fetchCampaigns = async () => {
      const data = await getCampaigns();
      setAllcampaign(data);
    };
    fetchCampaigns();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      {!showLayout && (
        <>
          <HomeButtons
            onRegisterClick={() => setOpenRegister(true)}
            onOngoingClick={() => router.push("/?showLayout=1#list")}
          />
          <RegisterModal open={openRegister} onClose={() => setOpenRegister(false)} />
        </>
      )}

      {showLayout && (
        <>
          <section id="creator">
            <Hero titleData={titleData} createCampaign={createCampaign} />
          </section>

          <section id="list" className="mt-8">
            <Card
              title="All Listed Campaign"
              allcampaign={searchResults.length > 0 ? searchResults : allcampaign}
              setOpenModel={setOpenModel}
              setDonate={setDonateCampaign}
            />
          </section>

          {openModel && (
            <PopUp
              setOpenModel={setOpenModel}
              getDonations={getDonations}
              donate={donateCampaign}
              setDonate={setDonateCampaign}  // ✅ IMPORTANT
              donateFunction={donate}
            />
          )}
        </>
      )}
    </>
  );
};

export default IndexPage;
