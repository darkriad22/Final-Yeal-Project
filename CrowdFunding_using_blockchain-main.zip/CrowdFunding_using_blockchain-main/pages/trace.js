// pages/trace.js
import { useEffect, useState, useContext, useMemo } from "react";
import { useRouter } from "next/router";
import { CrowdFundingContext } from "@/Context/CrowdFundingContext";

export default function Trace() {
  const router = useRouter();
  const { getDonations } = useContext(CrowdFundingContext);

  const [campaignId, setCampaignId] = useState(null);
  const [donors, setDonors] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  // 1) query ?c= 2) fallback hash JSON
  useEffect(() => {
    if (!router.isReady) return;

    setError("");
    setDonors([]);

    // try query param (?c=0 or ?campaignId=0)
    const q = router.query?.c ?? router.query?.campaignId;
    if (q !== undefined) {
      const idNum = Number(q);
      if (Number.isNaN(idNum) || idNum < 0) {
        setError("Invalid campaign id.");
        setCampaignId(null);
      } else {
        setCampaignId(idNum);
      }
      return;
    }

    // fallback: old hash JSON (#{"campaignId":0,...})
    try {
      if (typeof window === "undefined") return;
      const hash = window.location.hash.slice(1);
      if (!hash) return;

      const data = JSON.parse(decodeURIComponent(hash));
      if (typeof data?.campaignId === "number" && data.campaignId >= 0) {
        setCampaignId(data.campaignId);
      } else {
        setError("Invalid payload.");
        setCampaignId(null);
      }
    } catch {
      setError("Invalid or corrupted QR data.");
      setCampaignId(null);
    }
  }, [router.isReady, router.query?.c, router.query?.campaignId]);

  // donors fetch
  useEffect(() => {
    const run = async () => {
      if (campaignId === null) return;

      setLoading(true);
      setError("");
      try {
        const list = await getDonations(campaignId);
        setDonors(Array.isArray(list) ? list : []);
      } catch (e) {
        console.error("getDonations failed", e);
        setError("Failed to load donations for this campaign.");
        setDonors([]);
      } finally {
        setLoading(false);
      }
    };
    run();
  }, [campaignId, getDonations]);

  const totalRaised = useMemo(() => {
    if (!donors?.length) return "0.0";
    const sum = donors.reduce((acc, d) => acc + Number(d.donation || 0), 0);
    return (Math.round(sum * 10000) / 10000).toString();
  }, [donors]);

  const short = (addr) => (addr ? `${addr.slice(0, 6)}...${addr.slice(-4)}` : "");
  const shortTx = (tx) => (tx ? `${tx.slice(0, 18)}...${tx.slice(-8)}` : "");

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <div className="bg-white p-6 rounded-xl shadow w-full max-w-md">
        <h2 className="text-xl font-semibold mb-3">Donation Trace</h2>

        {campaignId === null && !error && (
          <p className="text-gray-600">Waiting for scan…</p>
        )}

        {error && (
          <p className="text-red-600 text-sm mb-2">{error}</p>
        )}

        {campaignId !== null && (
          <>
            <div className="mb-3 text-sm">
              <b>Campaign ID:</b> {campaignId}
            </div>

            {loading && <p className="text-gray-500 text-sm">Loading donations…</p>}

            {!loading && donors.length === 0 && !error && (
              <p className="text-gray-600 text-sm">No donations yet.</p>
            )}

            {!loading && donors.length > 0 && (
              <>
                <ul className="space-y-2 max-h-64 overflow-y-auto">
                  {donors.map((d, i) => (
                    <li
                      key={i}
                      className="bg-gray-100 rounded px-3 py-2 text-sm space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span>{short(d.donator)}</span>
                        <span className="font-medium">{d.donation} ETH</span>
                      </div>

                      {/* ✅ Proof (event log) */}
                      {d.txHash && (
                        <div className="text-xs text-gray-500 break-all">
                          Tx: {shortTx(d.txHash)}
                        </div>
                      )}

                      {/* optional if you also return donationId in context */}
                      {d.donationId && (
                        <div className="text-xs text-gray-500 break-all">
                          DonationID: {String(d.donationId).slice(0, 20)}...
                        </div>
                      )}
                    </li>
                  ))}
                </ul>

                <div className="mt-3 text-right">
                  <span className="text-sm text-gray-600 mr-2">Total Raised:</span>
                  <span className="font-semibold">{totalRaised} ETH</span>
                </div>
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}
