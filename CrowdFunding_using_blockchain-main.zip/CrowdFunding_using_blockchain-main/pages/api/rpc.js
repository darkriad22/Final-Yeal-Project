// pages/api/rpc.js
export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.status(405).json({ error: "Method not allowed" });
    return;
  }
  try {
    const rpc = process.env.NEXT_PUBLIC_RPC_HTTP_LOCAL || "http://127.0.0.1:8545";
    const r = await fetch(rpc, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(req.body),
    });
    const data = await r.text(); // pass-through
    res.status(r.status).send(data);
  } catch (e) {
    console.error("RPC proxy error:", e);
    res.status(500).json({ error: "RPC proxy failed" });
  }
}
