import React, { useState } from "react";
import { useRouter } from "next/router";

const AdminLogin = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showError, setShowError] = useState(false);
  const router = useRouter();

  const handleSubmit = (e) => {
    e.preventDefault();

    if (username === "mukul" && password === "1234") {
      setShowError(false);
      router.push("/admin_dashboard");
    } else {
      setShowError(true);
      setTimeout(() => setShowError(false), 2500); // Auto close after 2.5s
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-r from-blue-900 via-indigo-900 to-purple-900 flex items-center justify-center px-4 relative">
      {/* Error Popup */}
      {showError && (
        <div className="absolute top-10 z-50 flex justify-center w-full">
          <div className="bg-gradient-to-br from-pink-200 via-red-200 to-yellow-100 text-red-800 px-6 py-4 rounded-2xl shadow-xl border border-red-300 animate-fade-in scale-95 animate-scale-up">
            <p className="font-semibold text-lg">❌ Invalid username or password!</p>
          </div>
        </div>
      )}

      {/* Login Card */}
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-10 relative overflow-hidden">
        {/* Decorative circles */}
        <div className="absolute -top-20 -right-20 w-40 h-40 bg-indigo-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob"></div>
        <div className="absolute -bottom-20 -left-20 w-40 h-40 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000"></div>

        <div className="relative z-10">
          {/* Logo */}
          <div className="flex justify-center mb-8">
            <div className="w-20 h-20 bg-indigo-600 rounded-full flex items-center justify-center text-white font-bold text-3xl shadow-lg select-none">
              CF
            </div>
          </div>

          <h2 className="text-center text-3xl font-extrabold text-gray-900 mb-6">
            Admin Panel Login
          </h2>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="username" className="block text-sm font-semibold text-gray-700 mb-2">
                Username
              </label>
              <input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your username"
                required
                className="w-full px-5 py-3 border border-gray-300 rounded-lg shadow-sm
                  placeholder-gray-400 focus:outline-none focus:ring-4 focus:ring-indigo-500
                  focus:border-indigo-500 transition duration-300 ease-in-out"
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-semibold text-gray-700 mb-2">
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                required
                className="w-full px-5 py-3 border border-gray-300 rounded-lg shadow-sm
                  placeholder-gray-400 focus:outline-none focus:ring-4 focus:ring-indigo-500
                  focus:border-indigo-500 transition duration-300 ease-in-out"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 mt-4 bg-indigo-600 text-white font-semibold rounded-lg
                shadow-lg hover:bg-indigo-700 active:bg-indigo-800 transition duration-300 ease-in-out
                transform hover:-translate-y-0.5 focus:outline-none focus:ring-4 focus:ring-indigo-400"
            >
              Log In
            </button>
          </form>
        </div>
      </div>

      {/* Animations */}
      <style jsx>{`
        @keyframes blob {
          0%, 100% { transform: translate(0px, 0px) scale(1); }
          33% { transform: translate(30px, -50px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(-10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes scaleUp {
          from { transform: scale(0.9); }
          to { transform: scale(1); }
        }
        .animate-blob { animation: blob 7s infinite; }
        .animation-delay-2000 { animation-delay: 2s; }
        .animate-fade-in { animation: fadeIn 0.4s ease-out forwards; }
        .animate-scale-up { animation: scaleUp 0.4s ease-out forwards; }
      `}</style>
    </div>
  );
};

export default AdminLogin;
