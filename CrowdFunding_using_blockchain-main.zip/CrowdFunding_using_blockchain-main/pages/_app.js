import "@/styles/globals.css";
import { useRouter } from "next/router";
import { NavBar, Footer } from "@/Components";
import { CrowdFundingProvider } from "../Context/CrowdFundingContext";

export default function App({ Component, pageProps }) {
  const router = useRouter();

  // Check URL query param showLayout === "1"
  const showLayout = router.query.showLayout === "1";

  // Hide layout only on home page when showLayout is false
  const hideLayout = router.pathname === "/" && !showLayout;

  return (
    <CrowdFundingProvider>
      {!hideLayout && <NavBar />}
      <Component {...pageProps} />
      {!hideLayout && <Footer />}
    </CrowdFundingProvider>
  );
}
