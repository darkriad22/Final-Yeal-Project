const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("CrowdFunding Gas Report", function () {
  it("register → create → donate → close → withdraw", async function () {
    const [owner, donor] = await ethers.getSigners();

    // Deploy
    const CrowdFunding = await ethers.getContractFactory("CrowdFunding");
    const cf = await CrowdFunding.deploy();
    await cf.deployed();

    // Register members
    await (await cf.connect(owner).register("Owner")).wait();
    await (await cf.connect(donor).register("Donor")).wait();

    // Create campaign
    const target = ethers.utils.parseEther("1");
    const now = (await ethers.provider.getBlock("latest")).timestamp;
    const deadline = now + 7 * 24 * 60 * 60;

    await (
      await cf.connect(owner).createCampaign(
        owner.address,
        "Gas Test",
        "Testing gas cost",
        target,
        deadline,
        "img"
      )
    ).wait();

    const id = 0;

    // Donate (0.5 + 0.5 = 1.0)
    await (
      await cf.connect(donor).donateToCampaign(id, {
        value: ethers.utils.parseEther("0.5"),
      })
    ).wait();

    await (
      await cf.connect(donor).donateToCampaign(id, {
        value: ethers.utils.parseEther("0.5"),
      })
    ).wait();

    // Close
    await (await cf.connect(owner).closeCampaign(id)).wait();

    // Withdraw
    await (await cf.connect(owner).withdraw(id)).wait();

    const campaigns = await cf.getCampaigns();
    expect(campaigns[id].withdrawn).to.equal(true);
  });
});
