# CrowdFundingBD

CrowdFundingBD is a blockchain-based crowdfunding web application developed as a group academic project. The main goal of this project is to demonstrate how blockchain technology and smart contracts can be used to create a transparent, decentralized, and trustless crowdfunding system.

In traditional crowdfunding platforms, all funds and campaign data are controlled by a central authority. In contrast, CrowdFundingBD uses Ethereum smart contracts to manage campaigns and funds, reducing the need for third-party control and increasing transparency.

---

## Project Overview

The application allows users to create fundraising campaigns and contribute funds to existing campaigns using a blockchain network. Each campaign is managed by a smart contract written in Solidity, which ensures that transactions are recorded on the blockchain and cannot be altered.

The frontend of the application is built using Next.js and React, providing a user-friendly interface for interacting with the blockchain. The backend blockchain logic is handled using Hardhat, which is used for compiling, testing, and deploying smart contracts.

---

## How the System Works

1. A user connects their wallet (such as MetaMask) to the application.
2. The user can create a new crowdfunding campaign by providing campaign details.
3. Campaign information is stored and managed through smart contracts on the blockchain.
4. Other users can view available campaigns and contribute funds.
5. All transactions are processed through Ethereum smart contracts, ensuring transparency and security.

---

## Technology Stack

### Frontend
- Next.js
- React
- Tailwind CSS
- JavaScript

### Blockchain / Backend
- Solidity
- Hardhat
- Hardhat Ignition
- Ethereum (Local/Test Network)

---

## Project Structure

CrowdFundingBD-main/
│
├── Components/ # Reusable user interface components
├── Context/ # Blockchain context and application state
├── contracts/ # Solidity smart contracts
│ └── CrowdFunding.sol
├── ignition/ # Smart contract deployment modules
├── scripts/ # Deployment scripts
├── pages/ # Application pages
├── styles/ # Global styling files
├── test/ # Smart contract test cases
├── hardhat.config.js # Hardhat configuration
└── README.md