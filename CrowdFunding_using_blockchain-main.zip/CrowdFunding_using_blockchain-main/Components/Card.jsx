import React from "react";

const Card = ({ allcampaign, setOpenModel, setDonate, title }) => {
  const daysLeft = (deadline) => {
    const difference = new Date(deadline).getTime() - Date.now();
    const remainingDays = difference / (1000 * 3600 * 24);
    return remainingDays.toFixed(0);
  };

  const getStatus = (c) => {
    const now = Date.now();
    const ended = now > Number(c.deadline || 0);

    if (c.isDeleted) return "Deleted";
    if (c.withdrawn) return "Withdrawn";
    if (c.canceled) return "Canceled";
    if (c.closed) return "Closed";
    if (ended) return "Ended";
    return "Active";
  };

  return (
    <div className="max-w-7xl mx-auto px-8 py-10">
      <p className="py-10 text-4xl font-bold leading-7 text-center text-deep-purple-accent-400">
        {title}
      </p>

      <div className="grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
        {allcampaign?.map((campaign) => (
          <div
            onClick={() => {
              // ✅ always pass the REAL campaign object with pId (on-chain id)
              setDonate(campaign);
              setOpenModel(true);
            }}
            // ✅ IMPORTANT: use stable on-chain id, never index
            key={campaign.pId}
            className="cursor-pointer border overflow-hidden transition-shadow duration-300 bg-white rounded-lg shadow-lg hover:shadow-2xl"
          >
            <img
              src={campaign.image}
              className="object-cover w-full h-64 rounded-t-lg"
              alt={campaign.title}
            />

            <div className="py-5 px-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs font-semibold text-gray-600 uppercase">
                  Days Left: {daysLeft(campaign.deadline)}
                </p>

                <p className="text-xs font-semibold text-gray-700 uppercase">
                  Status: <span className="text-indigo-600">{getStatus(campaign)}</span>
                </p>
              </div>

              <p className="inline-block mb-3 text-black">
                <span className="text-xl font-bold leading-5">{campaign.title}</span>
              </p>

              <p className="mb-4 text-gray-700">{campaign.description}</p>

              <div className="flex flex-col gap-1">
                <p className="font-semibold text-deep-purple-accent-400">
                  Target: {campaign.target} ETH
                </p>

                <p className="font-semibold text-green-500">
                  Raised: {campaign.amountCollected} ETH
                </p>

                {/* ✅ Debug helper: show id to confirm no mismatch */}
                <p className="text-xs text-gray-500">
                  Campaign ID: {campaign.pId}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Card;
