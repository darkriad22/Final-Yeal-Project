import Footer from "./Footer";
import NavBar from "./NavBar";
import Logo from "./Logo";
import Hero from "./Hero";
import PopUp from "./PopUp";
import Card from "./Card";

export {Footer,NavBar,Logo,Card,PopUp,Hero};