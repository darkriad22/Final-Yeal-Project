// Components/QrScanner.jsx
import React, { useState, useCallback } from "react";
import dynamic from "next/dynamic";
import { useRouter } from "next/router";

// Only load on client
const Scanner = dynamic(
  () => import("@yudiel/react-qr-scanner").then(m => m.Scanner),
  { ssr: false }
);

export default function QrScanner() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [last, setLast] = useState("");

  const handleScan = useCallback((result) => {
    if (!result || !result[0]?.rawValue) return;
    const text = result[0].rawValue;
    setLast(text);

    // যদি আমাদের trace URL হয় → সরাসরি সেখানে যাও
    if (text.startsWith("http") && text.includes("/trace#")) {
      router.push(text);
      return;
    }
    // না হলে JSON হিসেবে চেষ্টা করো
    try {
      const payload = JSON.parse(text);
      const hash = encodeURIComponent(JSON.stringify(payload));
      router.push(`/trace#${hash}`);
    } catch {
      // প্লেইন টেক্সট হলে minimally wrap
      const hash = encodeURIComponent(JSON.stringify({ donationId: text }));
      router.push(`/trace#${hash}`);
    }
  }, [router]);

  return (
    <div className="w-full mb-6">
      <div className="flex items-center justify-between bg-white/80 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl px-4 py-3">
        <div className="font-medium">Scan Donation QR</div>
        <button
          onClick={() => setOpen(v => !v)}
          className={`px-3 py-1.5 rounded-lg text-white ${open ? "bg-red-600" : "bg-purple-600"}`}
        >
          {open ? "Close Scanner" : "Open Scanner"}
        </button>
      </div>

      {open && (
        <div className="mt-3 overflow-hidden rounded-xl border border-gray-200 dark:border-gray-700">
          <Scanner
            onScan={handleScan}
            components={{ audio: false }}  // বিফ ধরে চাইলে বীপ বন্ধ
            styles={{ container: { width: "100%" }, video: { width: "100%" } }}
            constraints={{ facingMode: "environment" }}
          />
        </div>
      )}

      {!!last && (
        <p className="mt-2 text-sm text-gray-500 break-all">
          Last scan: {last}
        </p>
      )}
    </div>
  );
}
