import Link from "next/link";
import React from "react";

const HomeButtons = ({ onRegisterClick, onOngoingClick }) => {
  return (
    <div className="min-h-screen bg-gradient-to-tr from-indigo-900 via-purple-900 to-pink-900 flex items-center justify-center px-4 py-20">
      <div className="bg-white bg-opacity-90 backdrop-blur-md rounded-3xl shadow-2xl p-10 w-full max-w-sm">
        <h2 className="text-3xl font-extrabold text-gray-900 mb-8 text-center tracking-wide">
          Welcome to CrowdFundingBD
        </h2>

        <nav className="flex flex-col space-y-6">
          {/* Create Campaign */}
          <Link
            href="/?showLayout=1#creator"
            className="flex items-center justify-center gap-3 px-6 py-3 rounded-xl bg-purple-700 text-white font-semibold shadow-lg
              hover:bg-purple-800 transition duration-300 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-purple-400"
          >
            {/* plus-circle */}
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none"
              viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
            </svg>
            Create Campaign
          </Link>

          {/* Register as Member (opens modal) */}
          <button
            onClick={onRegisterClick}
            className="flex items-center justify-center gap-3 px-6 py-3 rounded-xl bg-gray-900 text-white font-semibold shadow-lg
              hover:bg-gray-800 transition duration-300 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-gray-400"
          >
            {/* user-add */}
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none"
              viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round"
                d="M15 7a3 3 0 11-6 0 3 3 0 016 0zM4 21v-2a4 4 0 014-4h4m6-6v6m3-3h-6" />
            </svg>
            Register as Member
          </button>

          {/* Ongoing Campaigns */}
          <button
            onClick={onOngoingClick}
            className="flex items-center justify-center gap-3 px-6 py-3 rounded-xl bg-green-600 text-white font-semibold shadow-lg
              hover:bg-green-700 transition duration-300 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-green-400"
          >
            {/* list-bullet */}
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none"
              viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round"
                d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" />
            </svg>
            Ongoing Campaigns
          </button>
        </nav>
      </div>
    </div>
  );
};

export default HomeButtons;
