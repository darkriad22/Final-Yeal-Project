import React, { useState, useContext } from "react";
import { CrowdFundingContext } from "@/Context/CrowdFundingContext";

export default function RegisterModal({ open, onClose }) {
  const { registerMember } = useContext(CrowdFundingContext);

  const [name, setName] = useState("");
  const [submitting, setSubmitting] = useState(false);

  if (!open) return null;

  const submit = async () => {
    if (!name || !name.trim()) return alert("Name required");

    try {
      setSubmitting(true);

      // ✅ NEW: register(name) only
      await registerMember(name.trim());

      alert("Registered successfully!");
      setName("");
      onClose();
    } catch (e) {
      console.log("register error", e);

      const msg =
        e?.error?.data?.originalError?.message ||
        e?.error?.data?.message ||
        e?.error?.message ||
        e?.reason ||
        e?.data?.message ||
        e?.message ||
        "";

      if (msg.toLowerCase().includes("already registered")) {
        alert("You are already registered with this wallet.");
      } else if (msg.toLowerCase().includes("connect wallet")) {
        alert("Connect wallet first.");
      } else if (msg.toLowerCase().includes("user rejected")) {
        alert("Transaction rejected.");
      } else {
        alert(msg || "Registration failed");
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-6 w-full max-w-sm space-y-3">
        <h3 className="text-xl font-semibold">Register as Member</h3>

        <input
          placeholder="Name"
          value={name}
          className="border p-2 rounded w-full"
          onChange={(e) => setName(e.target.value)}
        />

        <div className="flex gap-3 justify-end pt-2">
          <button className="px-3 py-2" onClick={onClose} disabled={submitting}>
            Close
          </button>

          <button
            className="px-3 py-2 bg-purple-700 disabled:bg-purple-400 text-white rounded"
            onClick={submit}
            disabled={submitting}
          >
            {submitting ? "Registering..." : "Register"}
          </button>
        </div>

        <p className="text-xs text-gray-500 pt-2">
          ✅ Password is not stored on-chain. Membership is linked to your wallet address.
        </p>
      </div>
    </div>
  );
}
