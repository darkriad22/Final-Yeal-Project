// Components/PopUp.jsx
import React, { useState, useEffect, useContext, useMemo } from "react";
import { QRCodeCanvas } from "qrcode.react";
import { CrowdFundingContext } from "../Context/CrowdFundingContext";

const PopUp = ({ setOpenModel, donate, setDonate, donateFunction, getDonations }) => {
  const [amount, setAmount] = useState("");
  const [allDonationData, setAllDonationData] = useState([]);
  const [qr, setQr] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const [escrowBalance, setEscrowBalance] = useState("0");
  const [myContribution, setMyContribution] = useState("0");
  const [actionLoading, setActionLoading] = useState(false);

  const {
    deleteCampaign,
    currentAccount,
    withdraw,
    refund,
    cancelCampaign,
    closeCampaign,
    getMyContribution,
    getContractBalance,
    getCampaigns,
  } = useContext(CrowdFundingContext);

  const shortAddr = (addr) => (addr ? `${addr.slice(0, 6)}...${addr.slice(-4)}` : "");

  const isOwner =
    donate?.owner &&
    currentAccount &&
    donate.owner.toLowerCase() === currentAccount.toLowerCase();

  const nowMs = Date.now();
  const isEnded = nowMs > Number(donate?.deadline || 0);

  const raised = useMemo(() => {
    const v = parseFloat(donate?.amountCollected || "0");
    return Number.isFinite(v) ? v : 0;
  }, [donate?.amountCollected]);

  const target = useMemo(() => {
    const v = parseFloat(donate?.target || "0");
    return Number.isFinite(v) ? v : 0;
  }, [donate?.target]);

  const status = useMemo(() => {
    if (donate?.isDeleted) return "Deleted";
    if (donate?.canceled) return "Canceled";
    if (donate?.withdrawn) return "Withdrawn";
    if (donate?.closed) return "Closed (Ready to Withdraw)";

    if (!isEnded) {
      if (target > 0 && raised >= target) return "Goal Reached ✅ (Owner can Close)";
      return "Active";
    }

    if (raised >= target && target > 0) return "Successful (Owner can Withdraw)";
    return "Failed (Refund Available)";
  }, [donate?.isDeleted, donate?.canceled, donate?.withdrawn, donate?.closed, isEnded, raised, target]);

  const canClose = useMemo(() => {
    return (
      isOwner &&
      !donate?.isDeleted &&
      !donate?.canceled &&
      !donate?.withdrawn &&
      !donate?.closed &&
      target > 0 &&
      raised >= target
    );
  }, [isOwner, donate?.isDeleted, donate?.canceled, donate?.withdrawn, donate?.closed, raised, target]);

  const canWithdraw = useMemo(() => {
    return (
      isOwner &&
      !donate?.isDeleted &&
      !donate?.canceled &&
      !donate?.withdrawn &&
      target > 0 &&
      raised >= target &&
      (donate?.closed || isEnded)
    );
  }, [isOwner, donate?.isDeleted, donate?.canceled, donate?.withdrawn, donate?.closed, isEnded, raised, target]);

  const canCancel = useMemo(() => {
    return isOwner && !donate?.isDeleted && !donate?.canceled && !donate?.withdrawn;
  }, [isOwner, donate?.isDeleted, donate?.canceled, donate?.withdrawn]);

  const canRefund = useMemo(() => {
    const myAmt = parseFloat(myContribution || "0");
    const hasContribution = Number.isFinite(myAmt) && myAmt > 0;
    const refundWindow =
      !donate?.withdrawn &&
      !donate?.isDeleted &&
      (donate?.canceled || (isEnded && raised < target));

    return !isOwner && hasContribution && refundWindow;
  }, [myContribution, donate?.withdrawn, donate?.isDeleted, donate?.canceled, isEnded, raised, target, isOwner]);

  const refreshSideInfo = async () => {
    try {
      const bal = await getContractBalance();
      setEscrowBalance(bal);
    } catch (e) {}

    try {
      const myAmt = await getMyContribution(donate.pId);
      setMyContribution(myAmt);
    } catch (e) {}
  };

  // ✅ Modal এর donate object refresh (Close/Withdraw/Cancel এর পর UI update ঠিক রাখতে)
  const refreshModalCampaign = async () => {
    try {
      const list = await getCampaigns();
      const fresh = list?.find((c) => Number(c.pId) === Number(donate.pId));
      if (fresh && setDonate) setDonate(fresh);
    } catch (e) {
      console.log("refreshModalCampaign error", e);
    }
  };

  const createDonation = async () => {
    if (!amount || Number(amount) <= 0) {
      alert("Enter a valid amount (ETH)");
      return;
    }

    if (donate?.isDeleted || donate?.canceled || donate?.withdrawn || donate?.closed || isEnded) {
      alert("Donations are not allowed (campaign is closed/canceled/ended).");
      return;
    }

    try {
      setSubmitting(true);
      const res = await donateFunction(donate.pId, amount);

      const donationData = await getDonations(donate.pId);
      setAllDonationData(donationData);

      await refreshModalCampaign();
      await refreshSideInfo();

      setQr({ id: res?.donationId || "UNKNOWN", amount });
      setAmount("");
    } catch (error) {
      console.log(error);

      const msg =
        error?.error?.data?.originalError?.message ||
        error?.error?.data?.message ||
        error?.error?.message ||
        error?.reason ||
        error?.data?.message ||
        error?.message ||
        "";

      if (msg.includes("NOT_REGISTERED") || msg.includes("Register first")) {
        alert("Please register first to donate.");
      } else if (msg.includes("Target reached") || msg.includes("TARGET_REACHED")) {
        alert("Target amount has been reached. No more donations accepted.");
      } else if (msg.includes("Exceeds target") || msg.includes("EXCEEDS_TARGET")) {
        alert("Donation exceeds target. Try a smaller amount.");
      } else if (msg.includes("Already closed")) {
        alert("Already closed. Now you can withdraw.");
        await refreshModalCampaign();
      } else if (msg.includes("Campaign closed") || msg.includes("CAMPAIGN_CLOSED")) {
        alert("Campaign is closed. No more donations accepted.");
      } else if (msg.includes("Campaign has ended") || msg.includes("CAMPAIGN_ENDED")) {
        alert("This campaign has ended.");
      } else if (msg.includes("Campaign canceled") || msg.includes("CAMPAIGN_CANCELED")) {
        alert("This campaign is canceled.");
      } else if (msg.toLowerCase().includes("insufficient funds")) {
        alert("Insufficient funds in your wallet.");
      } else if (msg.toLowerCase().includes("user rejected")) {
        alert("Transaction rejected.");
      } else {
        alert(msg || "Donation failed. See console for details.");
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteCampaign = async () => {
    try {
      await deleteCampaign(donate.pId);
      await getCampaigns();
      setOpenModel(false);
    } catch (e) {
      console.log(e);
      alert("Delete failed. Check console.");
    }
  };

  const handleWithdraw = async () => {
    try {
      setActionLoading(true);
      await withdraw(donate.pId);

      await refreshModalCampaign();
      await refreshSideInfo();

      alert("Withdraw successful!");
    } catch (e) {
      console.log(e);
      const msg =
        e?.error?.data?.originalError?.message ||
        e?.error?.data?.message ||
        e?.error?.message ||
        e?.reason ||
        e?.data?.message ||
        e?.message ||
        "";
      alert(msg || "Withdraw failed. Check console.");
    } finally {
      setActionLoading(false);
    }
  };

  const handleRefund = async () => {
    try {
      setActionLoading(true);
      await refund(donate.pId);

      await refreshModalCampaign();
      await refreshSideInfo();

      alert("Refund successful!");
    } catch (e) {
      console.log(e);
      const msg =
        e?.error?.data?.originalError?.message ||
        e?.error?.data?.message ||
        e?.error?.message ||
        e?.reason ||
        e?.data?.message ||
        e?.message ||
        "";
      alert(msg || "Refund failed. Check console.");
    } finally {
      setActionLoading(false);
    }
  };

  const handleCancel = async () => {
    try {
      setActionLoading(true);
      await cancelCampaign(donate.pId);

      await refreshModalCampaign();
      await refreshSideInfo();

      alert("Campaign canceled!");
    } catch (e) {
      console.log(e);
      const msg =
        e?.error?.data?.originalError?.message ||
        e?.error?.data?.message ||
        e?.error?.message ||
        e?.reason ||
        e?.data?.message ||
        e?.message ||
        "";
      alert(msg || "Cancel failed. Check console.");
    } finally {
      setActionLoading(false);
    }
  };

  const handleClose = async () => {
    try {
      setActionLoading(true);

      // ✅ Option-A: only close here
      await closeCampaign(donate.pId);

      await refreshModalCampaign();
      await refreshSideInfo();

      alert("Campaign closed! Now you can withdraw.");
    } catch (e) {
      console.log(e);
      const msg =
        e?.error?.data?.originalError?.message ||
        e?.error?.data?.message ||
        e?.error?.message ||
        e?.reason ||
        e?.data?.message ||
        e?.message ||
        "";

      if (msg.includes("Already closed")) {
        await refreshModalCampaign();
        alert("Already closed. Now you can withdraw.");
      } else {
        alert(msg || "Close failed. Check console.");
      }
    } finally {
      setActionLoading(false);
    }
  };

  useEffect(() => {
    const fetchDonations = async () => {
      const donationData = await getDonations(donate.pId);
      setAllDonationData(donationData);
    };
    fetchDonations();
    refreshSideInfo();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [donate.pId]);

  // QR URL
  const baseUrl =
    (typeof window !== "undefined" && process.env.NEXT_PUBLIC_BASE_URL) ||
    (typeof window !== "undefined" ? window.location.origin : "");

  const qrUrl = `${baseUrl}/trace?c=${donate.pId}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center overflow-x-hidden overflow-y-auto outline-none focus:outline-none bg-black bg-opacity-50">
      <div className="relative w-auto mx-auto max-w-3xl">
        <div className="border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-gray-800 text-white outline-none focus:outline-none">
          {/* Header */}
          <div className="flex items-start justify-between p-5 border-b border-solid border-gray-600 rounded-t">
            <div>
              <h3 className="text-3xl font-semibold">{donate.title}</h3>
              <p className="text-sm text-gray-400">Owner: {shortAddr(donate.owner)}</p>
              <p className="text-sm mt-1">
                <span className="opacity-70">Status:</span>{" "}
                <span className="font-semibold">{status}</span>
              </p>
            </div>
            <button
              className="p-1 ml-auto border-0 text-white opacity-50 hover:opacity-100 transition-opacity duration-200"
              onClick={() => setOpenModel(false)}
              aria-label="Close"
            >
              <span className="text-2xl">×</span>
            </button>
          </div>

          {/* Body */}
          <div className="relative p-6 flex-auto">
            <p className="my-4 text-gray-300 leading-relaxed">{donate.description}</p>

            {/* Raised + Target + Escrow */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
              <div className="p-3 bg-gray-900 rounded">
                <div className="text-xs opacity-70">Raised (Escrow)</div>
                <div className="text-lg font-semibold">{raised.toFixed(4)} ETH</div>
              </div>
              <div className="p-3 bg-gray-900 rounded">
                <div className="text-xs opacity-70">Target</div>
                <div className="text-lg font-semibold">{target.toFixed(4)} ETH</div>
              </div>
              <div className="p-3 bg-gray-900 rounded">
                <div className="text-xs opacity-70">Total Contract Balance (All Campaigns)</div>
                <div className="text-lg font-semibold">{Number(escrowBalance).toFixed(4)} ETH</div>
              </div>
            </div>

            {/* My contribution */}
            {currentAccount && (
              <div className="p-3 bg-gray-900 rounded mb-4">
                <div className="text-xs opacity-70">My Contribution</div>
                <div className="text-sm">
                  {Number(myContribution || 0).toFixed(4)} ETH{" "}
                  <span className="opacity-70">({shortAddr(currentAccount)})</span>
                </div>
              </div>
            )}

            <div className="grid gap-3">
              <input
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Amount in ETH"
                required
                inputMode="decimal"
                pattern="^[0-9]*[.]?[0-9]*$"
                type="text"
                className="flex-grow w-full h-12 px-4 transition duration-200 bg-gray-700 border border-gray-600 rounded shadow-sm appearance-none focus:border-purple-400 focus:outline-none focus:shadow-outline"
              />

              {/* Owner/Donor actions */}
              <div className="flex flex-wrap gap-2">
                {canCancel && (
                  <button
                    className="bg-yellow-600 disabled:bg-yellow-900 text-white font-bold uppercase text-sm px-4 py-2 rounded shadow hover:shadow-lg transition-all"
                    type="button"
                    onClick={handleCancel}
                    disabled={actionLoading}
                  >
                    {actionLoading ? "Processing..." : "Cancel Campaign"}
                  </button>
                )}

                {canClose && (
                  <button
                    className="bg-indigo-600 disabled:bg-indigo-900 text-white font-bold uppercase text-sm px-4 py-2 rounded shadow hover:shadow-lg transition-all"
                    type="button"
                    onClick={handleClose}
                    disabled={actionLoading}
                  >
                    {actionLoading ? "Processing..." : "Close Campaign"}
                  </button>
                )}

                {canWithdraw && (
                  <button
                    className="bg-green-600 disabled:bg-green-900 text-white font-bold uppercase text-sm px-4 py-2 rounded shadow hover:shadow-lg transition-all"
                    type="button"
                    onClick={handleWithdraw}
                    disabled={actionLoading}
                  >
                    {actionLoading ? "Processing..." : "Withdraw"}
                  </button>
                )}

                {canRefund && (
                  <button
                    className="bg-blue-600 disabled:bg-blue-900 text-white font-bold uppercase text-sm px-4 py-2 rounded shadow hover:shadow-lg transition-all"
                    type="button"
                    onClick={handleRefund}
                    disabled={actionLoading}
                  >
                    {actionLoading ? "Processing..." : "Claim Refund"}
                  </button>
                )}
              </div>

              {/* QR */}
              <div className="mt-2 p-3 bg-gray-900 rounded">
                <p className="mb-2 text-sm text-gray-200">
                  Scan to view all donors for this campaign
                </p>
                <div className="flex items-center gap-4">
                  <QRCodeCanvas
                    value={qrUrl}
                    size={220}
                    level="M"
                    includeMargin={true}
                    bgColor="#ffffff"
                    fgColor="#000000"
                  />
                  <div className="text-sm break-all">
                    <div className="opacity-70 mb-1">URL:</div>
                    <div className="max-w-[280px]">{qrUrl}</div>
                    <a
                      href={qrUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="text-purple-300 underline mt-2 inline-block"
                    >
                      Open trace page
                    </a>
                  </div>
                </div>
              </div>

              {/* Donation history */}
              {allDonationData.length > 0 && (
                <div className="max-h-40 overflow-y-auto bg-gray-900 p-2 rounded">
                  <p className="my-2 text-white text-lg leading-relaxed bg-gray-700 p-2 rounded">
                    Donation History
                  </p>
                  {allDonationData.map((d, i) => (
                    <p
                      key={i}
                      className="my-2 text-white text-sm leading-relaxed bg-gray-700 p-2 rounded"
                    >
                      {i + 1}: {d.donation} ETH — {shortAddr(d.donator)}
                    </p>
                  ))}
                </div>
              )}

              {/* Last receipt */}
              {qr && (
                <div className="p-3 bg-gray-900 rounded">
                  <p className="text-sm text-gray-200 mb-1">Last Donation Receipt</p>
                  <div className="text-xs">
                    <div>
                      <span className="opacity-70">Donation ID:</span> {qr.id}
                    </div>
                    <div>
                      <span className="opacity-70">Amount:</span> {qr.amount} ETH
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Footer */}
          <div className="flex items-center justify-end p-6 gap-2 border-t border-solid border-gray-600 rounded-b">
            <button
              className="text-red-400 background-transparent font-bold uppercase px-6 py-2 text-sm outline-none focus:outline-none ease-linear transition-all duration-150"
              type="button"
              onClick={() => setOpenModel(false)}
            >
              Close
            </button>

            <button
              className="bg-purple-600 disabled:bg-purple-900 text-white active:bg-purple-700 font-bold uppercase text-sm px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none ease-linear transition-all duration-150"
              type="button"
              onClick={createDonation}
              disabled={
                submitting ||
                donate?.isDeleted ||
                donate?.canceled ||
                donate?.withdrawn ||
                donate?.closed ||
                isEnded
              }
            >
              {submitting ? "Processing..." : "Donate"}
            </button>

            {isOwner && (
              <button
                className="text-red-400 background-transparent font-bold uppercase px-6 py-2 text-sm outline-none focus:outline-none ease-linear transition-all duration-150"
                type="button"
                onClick={handleDeleteCampaign}
              >
                Delete Campaign
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PopUp;
